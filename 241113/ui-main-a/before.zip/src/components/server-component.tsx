import React from "react";

const ServerComponent = () => {
  console.log("서버 컴포넌트!");
  return <div></div>;
};

export default ServerComponent;
