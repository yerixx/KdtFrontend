import React from "react";

const Price = () => {
  return <h1>Price</h1>;
};

export default Price;
