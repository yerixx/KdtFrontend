import React from "react";
import { Outlet } from "react-router-dom";
import { createGlobalStyle } from "styled-components";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";

const GlobalStyle = createGlobalStyle`
  @import url('https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@0,200..900;1,200..900&display=swap');
  
  @font-face {
    font-family: 'Source Sans 3';
    font-style: normal;
    src: url('https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@200;300;400;500;600;700;800;900&display=swap');
  }
  *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  ul,li{
    list-style:none;
  }
  a{
    text-decoration:none;
    color:inherit;
  }
  body{
    font-family: "Source Sans 3", sans-serif;
    background:${(props) => props.theme.bgColor};
    color:${(props) => props.theme.textColor};
  }
`;

const App = () => {
  return (
    <>
      <GlobalStyle />
      <Outlet />
      <ReactQueryDevtools initialIsOpen={false} buttonPosition={"top-right"} />
    </>
  );
};

export default App;
