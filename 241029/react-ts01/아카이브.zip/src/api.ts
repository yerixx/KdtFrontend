//fetcher Function 받는 역할
export const fetchCoins = async () => {
  const response = await fetch(
    "https://raw.githubusercontent.com/Divjason/coindata/refs/heads/main/coins.json"
  );
  if (!response.ok) {
    throw new Error("Failed to fetch coins");
  }
  return response.json();
};

export function fetchCoinInfo(coinId: string | undefined) {
  return fetch(`https://api.coinpaprika.com/v1/coins/${coinId}`).then(
    (response) => response.json()
  );
}

export const fetchCoinPrice = (coinId: string | undefined) => {
  return fetch(
    `https://my-json-server.typicode.com/Divjason/coinprice/coinprice/${coinId}`
  ).then((response) => response.json());
};

export const fetchCoinHistory = (coinId: string | undefined) => {
  const endDate = Math.floor(Date.now() / 1000);
  const startDate = endDate - 60 * 60 * 24 * 7;
  return fetch(
    `https://ohlcv-api.nomadcoders.workers.dev/?coinId=${coinId}&start=${startDate}&end=${endDate}`
  );
};
